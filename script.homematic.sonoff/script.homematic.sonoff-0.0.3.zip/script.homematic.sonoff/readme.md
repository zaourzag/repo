<h1>Sonoff WLAN Multichannel Switcher</h1>

Switch your illumination or devices at home with your Kodi remote. All you need is a Sonoff WLAN (multichannel) switch device from Itead in your home automation equipment. Interesting? Visit [B]itead.cc[/B] to see more.