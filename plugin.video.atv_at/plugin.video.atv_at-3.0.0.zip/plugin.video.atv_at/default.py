﻿import resources.lib.index
