plugin.video.putpat
===================

This is a plugin for XBMC (http://xbmc.org).


Thanks "membrane" for the original idea of this plugin!
