service.tvh.manager
===================

Addon for 'PVR Timer- and Powermanagement' for XBMC/Kodi

Poweroff management for current active recordings and wakeup procedures for future schedules 
using the XML-Interface of TVHeadend. This plugin starts and shuts down the htpc if a
recording is scheduled. It delivers optional Emails via SMTP if an automatic scheduled 
Recording ended successfully. 

The plugin starts the system periodically on an user defined cycle and time for e.g. 
EPG-Updates too if there is a longer inactivity time of the system or user.
