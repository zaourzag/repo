from resources.lib.kodion import runner
from resources.lib import netzkino

__provider__ = netzkino.Provider()
runner.run(__provider__)