# skin.embuary
Embuary is based on the web UI of Emby and has been developed for Emby-For-kodi User.
Plese note that this skin is not 100% finished and it's in the alpha stage.

# Terms of use
With the installation of the skin you agree that you don't use it in combination with blacklisted and illegal Kodi add-ons.
You also agree that the skin installs a script called "script.service.caretaker". This service script scans your installed add-ons and notifies you if you have any blacklisted add-ons installed.
The addon doesn't track, store or report anything from you to me, the Kodi developers or anymone else. 

