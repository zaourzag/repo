# skin.embuary
Embuary is based on the web UI of Emby and has been developed for Emby-For-kodi User.

WIP