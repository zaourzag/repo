# skin.embuary
Embuary is based on the web UI of Emby and has been developed for Emby-For-kodi User.
Please note that this skin is not 100% finished and it's in the alpha stage.

# Terms of use
With the installation of the skin you agree that you don't use it in combination with blacklisted and illegal Kodi add-ons.
I'm not associated with any available build and I won't give any support to blacklisted, banned or illegal third party addons.