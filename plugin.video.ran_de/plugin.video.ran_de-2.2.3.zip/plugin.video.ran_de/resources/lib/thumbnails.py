import os.path

MEDIA_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'media')

THUMB_MAIN = os.path.join(MEDIA_PATH, 'thumb_main.jpg')