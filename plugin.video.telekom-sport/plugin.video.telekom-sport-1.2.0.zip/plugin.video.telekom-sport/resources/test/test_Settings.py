# -*- coding: utf-8 -*-
# Module: Settings
# Author: asciidisco
# Created on: 24.07.2017
# License: MIT https://goo.gl/xF5sC4

"""Tests for the `Settings` module"""

import unittest
from resources.lib.Settings import Settings

class SettingsTestCase(unittest.TestCase):
    """Tests for the `Settings` module"""

    def test_dummy(self):
        """ADD ME"""
        self.assertEqual(True, True)
