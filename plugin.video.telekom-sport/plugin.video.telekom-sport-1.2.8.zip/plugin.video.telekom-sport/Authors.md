Authors
=======

[asciidisco](https://github.com/asciidisco)
[ci skip](https://github.com/ci skip)
[Benjamin](https://github.com/Benjamin)
[travis-ci](https://github.com/travis-ci)
