# -*- coding: utf-8 -*-
# Module: ContentLoader
# Author: asciidisco
# Created on: 24.07.2017
# License: MIT https://goo.gl/xF5sC4

"""Tests for the `ContentLoader` module"""

import unittest
from resources.lib.ContentLoader import ContentLoader

class ContentLoaderTestCase(unittest.TestCase):
    """Tests for the `ContentLoader` module"""

    def test_dummy(self):
        """ADD ME"""
        self.assertEqual(True, True)
