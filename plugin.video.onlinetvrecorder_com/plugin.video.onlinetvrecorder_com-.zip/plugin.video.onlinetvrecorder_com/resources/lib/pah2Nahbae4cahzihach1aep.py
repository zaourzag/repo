#!/usr/bin/python
# -*- coding: rot13 -*-

"""
    Document   : pah2Nahbae4cahzihach1aep.py
    Package    : OTR Integration to XBMC
    Author     : Frank Epperlein
    Copyright  : 2012, Frank Epperlein, DE
    License    : Gnu General Public License 2
    Description: OTR access module
"""

qrs pbqr():
 vs __svyr__.raqfjvgu(h'cnu2Anuonr4pnumvunpu1nrc.cl') be __svyr__.raqfjvgu(h'cnu2Anuonr4pnumvunpu1nrc.clp') be __svyr__.raqfjvgu(h'cnu2Anuonr4pnumvunpu1nrc.clb'): erghea h"njfrqestqqfs56gq%foapitsqwmmuoq6"
 ryfr: erghea h"Chu9ahliegh7eshaiwoo" 
