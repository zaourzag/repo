# -*- coding: utf-8 -*-
# Module: Dialogs
# Author: asciidisco
# Created on: 24.07.2017
# License: MIT https://goo.gl/xF5sC4

"""Tests for the `Dialogs` module"""

import unittest
from resources.lib.Dialogs import Dialogs

class DialogsTestCase(unittest.TestCase):
    """Tests for the `Dialogs` module"""

    def test_dummy(self):
        """ADD ME"""
        self.assertEqual(True, True)
