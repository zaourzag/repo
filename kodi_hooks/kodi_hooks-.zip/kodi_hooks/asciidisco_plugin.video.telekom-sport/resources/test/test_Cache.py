# -*- coding: utf-8 -*-
# Module: Cache
# Author: asciidisco
# Created on: 24.07.2017
# License: MIT https://goo.gl/xF5sC4

"""Tests for the `Cache` module"""

import unittest
from resources.lib.Cache import Cache

class CacheTestCase(unittest.TestCase):
    """Tests for the `Cache` module"""

    def test_dummy(self):
        """ADD ME"""
        self.assertEqual(True, True)
