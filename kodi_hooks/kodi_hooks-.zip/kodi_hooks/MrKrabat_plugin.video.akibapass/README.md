# Akibapass plugin for Kodi

Akibapass a KODI (XBMC) plugin for Akibapass.de.

Git repo: https://github.com/MrKrabat/plugin.video.akibapass

Forum posting: https://www.kodinerds.net/index.php/Thread/58346-Release-Akibapass-de/

**WARNING: You MUST be a PREMIUM member OR buy videos to use this plugin!**
***

Compatibility

| Device  | Kodi | Status |
| ------------- | ------------- | ------------- |
| Windows | 17.x  | Yes  |
| Linux | 17.x  | Yes  |
| MacOS | 17.x  | untested  |
| Android | 17.x  | Yes  |
| iOS | 17.x  | untested  |
| RaspberryPi | 17.x  | Yes  |
***

What this plugin currently can do:
- [x] Login with your account
- [x] Search for animes
- [x] Show "My Downloads"
- [x] Show "My Collection"
- [x] Show/browse all available anime
- [x] Show/browse all seasons/arcs of an anime
- [x] Show/browse all episodes of an season/arc
- [x] Display various informations (Kodi displays not all we provide)
- [x] Reactivate videos/streams
- [x] Watch videos you have bought
- [x] Watch videos with premium subscription

What is planned for the future:
- [ ] Select video resolution (only for videos you bought, streams are adaptive)

***

_Akibapass is a registered trademark of the peppermint anime gmbh.
This website and addon is not affiliated with Akibapass or peppermint anime gmbh._

_Kodi® (formerly known as XBMC™) is a registered trademark of the XBMC Foundation.
This website and addon is not affiliated with Kodi, Team Kodi, or the XBMC Foundation._