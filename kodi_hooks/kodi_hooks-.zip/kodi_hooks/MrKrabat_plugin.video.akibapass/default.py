# -*- coding: utf-8 -*-
# Akibapass - Watch videos from the german anime platform Akibapass.de on Kodi.
# Copyright (C) 2016 - 2017 MrKrabat
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import xbmc
import xbmcaddon


_plugId = "plugin.video.akibapass"

# plugin constants
__addon__   = xbmcaddon.Addon(id=_plugId)
__plugin__  = __addon__.getAddonInfo("name")
__version__ = __addon__.getAddonInfo("version")

xbmc.log("[PLUGIN] %s: version %s initialized" % (__plugin__, __version__))

if __name__ == "__main__":
    from resources.lib import akibapass
    # start addon
    akibapass.main()

sys.modules.clear()
